public class DecisionIA {


    public static String evaluarSolicitud(boolean tieneSancion, int copiasDisponibles) {

        if (tieneSancion) {
            return "RECHAZADO: El usuario tiene sanciones pendientes.";
        }

        if (copiasDisponibles > 0) {
            return "APROBADO: Reserva confirmada correctamente.";
        } else {
            return "ENCOLADO: Sin stock. El usuario pasa a la lista de espera.";
        }
    }

    public static void main(String[] args) {

        System.out.println("Caso 1: " + evaluarSolicitud(true, 3));

        System.out.println("Caso 2: " + evaluarSolicitud(false, 2));

        System.out.println("Caso 3: " + evaluarSolicitud(false, 0));
    }
}