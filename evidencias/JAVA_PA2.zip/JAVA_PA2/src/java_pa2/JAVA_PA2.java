/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package java_pa2;
import java.util.*;



public class JAVA_PA2{
    private static ArrayList<Libro> listaLibros = new ArrayList<>();

    public static void main(String[] args) {
        Libro L1 = new Libro("231", "lo que el viento se llevo", "tula", "accion", 10, 4);
        Libro L2 = new Libro("232", "mara muerta", "elicia", "novela", 8, 2);
        
        cantidad catalogo = new cantidad(5);
        
        listaLibros.add(L1);
        listaLibros.add(L1);
        
        System.out.println(catalogo.buscarPorISBN("232"));
        
        
    }
   
}
