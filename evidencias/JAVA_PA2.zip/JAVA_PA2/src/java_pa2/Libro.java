package java_pa2;
public class Libro {
    private String isbn;
    private String tituloString;
    private String autorString;
    private String categoriaString;
    private int ejemplaresTotales;
    private int ejemplaresDisponibles;
    
    public Libro(String isbnString,String titulo, String autor, String categoria, int ejemplaresTotal, int ejemplaresDisponibles)
    {
        this.isbn = isbnString;
        this.tituloString = titulo;
        this.autorString = autor;
        this.categoriaString = categoria;
        this.ejemplaresTotales = ejemplaresTotales;
        this.ejemplaresDisponibles = ejemplaresDisponibles;
    }
    public String getIsbn() { return isbn; }
    public String getTituloString() {return tituloString; }
    public String getAutorString() {return autorString;}
    public String getCategoriaString() {return categoriaString;}
    public int getEjemplaresTotales() {return ejemplaresTotales;}
    public int getEjemplaresDisponibles() {return ejemplaresDisponibles;}
    public String toString()
    {
        return "libro: " + tituloString + " autor: " + autorString + " Genero: " + categoriaString;
    }
    
}
