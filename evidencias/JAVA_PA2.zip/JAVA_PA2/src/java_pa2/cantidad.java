package java_pa2;
public class cantidad {
    private Libro[] libros;
    private int cantidad;
    
    public cantidad(int capacidad)
    {
        libros = new Libro[capacidad];
        cantidad = 0;
    }
    public Libro buscarPorISBN(String isbn)
    {
        for(int i = 0; i< cantidad; i++)
        {
            if (libros[i].getIsbn().equals(isbn)) {
                return libros[i];
            }
        }
        return null;
    }
    public int contarPorCatalogo(String categoria)
    {
        int contador = 0;
        for(int i = 0; i < cantidad; i++)
        {
            if(libros[i].getCategoriaString().equals(categoria))
            {
                contador++;
            }
        }
        return contador;
    }
    public void ordenarPorTitulo()
    {
        for(int i = 0; i < cantidad - 1; i++)
        {
            int menor = i;
            for(int j = i + 1; j < cantidad; j++)
            {
                if(libros[i].getTituloString().compareToIgnoreCase(libros[menor].getTituloString()) < 0)
                {
                    menor = j;
                }
            }
            Libro temp = libros[i];
            libros[i] = libros[menor];
            libros[menor] = temp;
        }
    }
}
