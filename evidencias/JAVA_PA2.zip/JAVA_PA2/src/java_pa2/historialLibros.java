package java_pa2;

public class historialLibros {
    private int[][] solicitudesPorMes;
    private String[] isbnLibros;
    
    public historialLibros(int numLibros)
    {
        solicitudesPorMes = new int[numLibros][12];
        isbnLibros = new String[numLibros];
    }
    
    
    public void registrarSolicitud(int filaLibro, int mes)
    {
        solicitudesPorMes[filaLibro][mes]++;
    }
    
    public int totalAnual(int filaLibro)
    {
        int total = 0;
        for(int mes = 0; mes < 12; mes ++)
        {
            total += solicitudesPorMes[filaLibro][mes];
        }
        return total;
    }
    
    public int mesMayorDemanda(int filaLibro)
    {
        int mejorMes = 0;
        int max = solicitudesPorMes[filaLibro][0];
        
        for(int mes = 1; mes < 12; mes++)
        {
            if(solicitudesPorMes[filaLibro][mes] > max)
            {
                mejorMes = mes;
            }
        }
        return mejorMes;
    }
    
    public int libroMasSolicitadoGlobal() {
        int filaGanadora = 0;
        int max = totalAnual(0);
        for (int i = 1; i < solicitudesPorMes.length; i++) {
            int total = totalAnual(i);
            if (total > max) {
                max = total;
                filaGanadora = i;
            }
        }
        return filaGanadora;
    }
}
